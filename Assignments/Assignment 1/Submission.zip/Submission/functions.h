void greetUser();
void printMenu();
void add(int, int);
void encrypt(char*, int);
void primeChecker(int);